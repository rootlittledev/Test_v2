package com.example.littledev.test_v2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void onLoginSuccess() {

        startActivity(new Intent(Login.this, Main.class));
        finish();
    }

    public void onLogin(View view) throws IOException, InterruptedException {
        EditText eLogin = (EditText) findViewById(R.id.username);
        EditText ePass = (EditText) findViewById(R.id.password);
        String login = eLogin.getText().toString();
        String pass = ePass.getText().toString();
        Sql_bridge bridge = new Sql_bridge(this);
        if(bridge.isConnected()){
            bridge.execute("login",login,pass);
        }
        else
            Toast.makeText(this, "No internet connection!", Toast.LENGTH_LONG).show();

    }

    public void onRegister(View view) {
        //startActivity(new Intent(this, Register.class));
    }
}
