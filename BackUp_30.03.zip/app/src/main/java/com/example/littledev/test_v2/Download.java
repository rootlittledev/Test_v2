package com.example.littledev.test_v2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by LittleDev on 3/30/2017.
 */

public class Download extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);
    }
}